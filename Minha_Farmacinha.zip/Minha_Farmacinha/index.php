<?php
    header("Location: paginas/home/home.php");
?>