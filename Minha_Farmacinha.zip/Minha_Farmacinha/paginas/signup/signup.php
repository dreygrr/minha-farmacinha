<?php
    $conexao = mysqli_connect('localhost', 'root', '', 'farmat_minhafarmacinha');

    $nome = $_POST['nome'];
    $email = $_POST['email'];
    $senha = $_POST['senha'];
    $foto = $_POST['foto'];
    
    $senha = base64_encode($senha);
    unset($_POST['senha']);

    if (!$conexao) {
        echo 'Houve algum erro na conexão com a base de dados.';
        exit;
    }

    $query = mysqli_query($conexao, "INSERT INTO usuario (nome, email, senha, foto) VALUES ('$nome', '$email', '$senha', '$foto')");
    unset($senha);

    if (!$query) {
        echo 'deu errado a query';
        
    }
    include 'certo_mensagem.php';
?>