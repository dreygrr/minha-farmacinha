<!DOCTYPE html>
    <html lang='pt-br'>
        <head>
            <meta charset='UTF-8'>
            <meta http-equiv='X-UA-Compatible' content='IE=edge'>
            <meta name='viewport' content='width=device-width, initial-scale=1.0'>

            <link rel='stylesheet' href='mensagem.css'>
            <link rel='stylesheet' href='https://use.fontawesome.com/releases/v5.4.1/css/all.css'>

            <title>FARMAT - Cadastrar</title>
    </head>
    <body>
        <div class='error-container'>
            <i id='icon1' class='fas fa-check'></i>
            <h1>Usuário cadastrado com sucesso!</h1>
            <p>O cadastro foi efetivado êxito.</p>

            <div class='botao-container'>
                <a id='voltar' href='signup.html'></a>
                <input id='cadastrar-outro' class='botao' type='submit' value='Cadastrar outro'>
            </div>

            <div class='botao-container'>
                <a id='voltar' href='../signin/signin_page.php'>
                    <input class='botao' type='submit' value='Entrar'>
                </a>
            </div>

            <div class='back-to-menu'>
                <a href='../home/home.php'><p>Voltar para a home</p></a>
            </div>
        </div>

        <div class='rodape'>
            <p>Política de privacidade | © 2021. Todos os direitos reservados.</p>
        </div>
    </body>
</html>