<?php
    require_once "../gravar/gravar.php";

    gravar($_POST, "REMÉDIO", "./../medicamentos.txt");
    
    echo <<<HTML
            <!DOCTYPE html>
            <html lang='pt-br'>
                <head>
                    <meta charset='UTF-8'>
                    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
                    <meta name='viewport' content='width=device-width, initial-scale=1.0'>

                    <link rel='stylesheet' href='./remedio_mensagem.css'>
                    <link rel='stylesheet' href='https://use.fontawesome.com/releases/v5.4.1/css/all.css'>

                    <title>FARMAT - Cadastrar Remédio</title>
                </head>
                <body>
                    <div class='error-container'>
                        <i id='icon1' class='fas fa-check'></i>
                        <h1>Remédio cadastrado com sucesso!</h1>
                        <p>O medicamento foi reservado com êxito.</p>

                        <a id='voltar' href='./cadastrar_remedio.html'>
                            <div class='botao-container'>
                                <input id='cadastrar-outro' class='botao' type='submit' value='Cadastrar outro'>
                            </div>
                        </a>
                        <a id='voltar' href='./../menu_usuario/menu_usuario.php'>
                            <div class='botao-container'>
                                <input class='botao' type='submit' value='Voltar'>
                            </div>
                        </a>

                        <div class='back-to-menu'>
                            <a href='./../../index.php'><p>Voltar para a home</p></a>
                        </div>
                    </div>
                </body>
            </html>
        HTML;
?>