<?php 
session_start();

if (!isset($_SESSION)) exit;

foreach ($_SESSION as $key => $value)
    unset($_SESSION[$key]);

unset($_SESSION);
session_destroy();
?>

<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        
        <link rel="stylesheet" href="signin.css">
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.4.1/css/all.css">
        
        <title>FARMAT - Entrar</title>
    </head>
    
    <body>
        <div class="form-container">
            <div class="logo-container">
                <a href="../home/home.php">
                    <img class="logo" src="../../img/logo-black.png" alt="Logo da FARMAT">
                </a>
            </div>

            <h1>Entrar</h1>

            <p>Insira os dados pedidos abaixo, por favor. Ainda não tem conta com a gente? <a href="../signup/signup.html">Cadastre-se já!</a></p>

            <form action="signin.php" method="POST">
                <div class="field">
                    <label>E-mail: </label>
                    <input type="text" name="email" required class="questao">
                </div>

                <div class="field">
                    <label>Senha: </label>
                    <input id="senha" type="password" name="senha" required class="questao"><i id="eye" class="far fa-eye" onclick="show()"></i>
                </div>

                <div class="botao-container">
                    <input type="submit" value="Entrar" class="botao">
                </div>
            </form>
            
            <a class="back-to-menu" href="../home/home.php"><p>Voltar para a home</p></a>
        </div>
        
        <div class="rodape">
            <p>Política de privacidade | © 2021. Todos os direitos reservados.</p>
        </div>
    </body>

    <script>
        var senha = document.getElementById("senha");

        function show() {
            if (senha.type === "password") {
                senha.type = "text";

                document.getElementsByTagName("i")[0].className = "far fa-eye-slash";
            } else {
                senha.type = "password";

                document.getElementsByTagName("i")[0].className = "far fa-eye";
            }
        }
    </script>
</html>