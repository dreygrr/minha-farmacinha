<?php
    $conexao = mysqli_connect('localhost', 'root', '', 'farmat_minhafarmacinha');

    $email = $_POST["email"];
    $senha = $_POST["senha"];

    if (!$conexao) {
        echo 'Houve algum erro na conexão com o banco de dados.';
        exit;
    }

    $query = mysqli_query($conexao, "SELECT * FROM Usuario WHERE email = '$email'");

    $res = mysqli_fetch_assoc($query);

    if ($res == 0) { //email errado?
        echo "E-mail ou senha inválidos.";
        exit;
    }

    $senhaDecoded = base64_decode($res['senha']);
    
    if ($senhaDecoded != $senha) { //senha errada?
        echo "E-mail ou senha inválidos.";
        exit;
    }

    unset($res['senha']); unset($senha);

    session_start();
    //foreach ($query as $key => $value) 
        //$_SESSION[$key] = $value;

    $_SESSION['email'] = $_POST['email'];
    $_SESSION['nome'] = $res['nome'];
    $_SESSION['foto'] = $res['foto'];
    
    header('Location: ../menu_usuario/menu_usuario.php');
    

    //     echo <<<HTML
    //         <!DOCTYPE html>
    //         <html lang='pt-br'>
    //             <head>
    //                 <meta charset='UTF-8'>
    //                 <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    //                 <meta name='viewport' content='width=device-width, initial-scale=1.0'>

    //                 <link rel='stylesheet' href='./signin.css'>
    //                 <link rel='stylesheet' href='https://use.fontawesome.com/releases/v5.4.1/css/all.css'>

    //                 <title>FARMAT - Entrar</title>
    //             </head>
    //             <body>
    //                 <div class='error-container'>
    //                     <i id='icon1' class='fas fa-times'></i>
    //                     <h1>Ops! Algo de errado aconteceu.</h1>
    //                     <p>Tente novamente, por favor.</p>

    //                     <a id='voltar' href='./signin.html'>
    //                         <div class='botao-container'>
    //                             <input class='botao' type='submit' value='Voltar'>
    //                         </div>
    //                     </a>

    //                     <div class='back-to-menu'>
    //                         <a href='./../index/index.php'><p>Voltar para a home</p></a>
    //                     </div>
    //                 </div>
    //             </body>
    //         </html>
    //     HTML;
    
?>