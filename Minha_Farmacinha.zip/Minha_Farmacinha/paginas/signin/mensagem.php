<html>
    <head>
        <link rel='stylesheet' href='https://use.fontawesome.com/releases/v5.4.1/css/all.css'>
        <style>
            .message {
                display: flex; justify-content: center; align-items: center;
                width: 100%; padding: 10px;
                background-color: #08aa3e;
                color: white;
            }
        </style>
    </head>

    <body>
        <div class='message'>
            Você fez log-in com sucesso!
        </div>
    </body>
</html>