<!--MINHA FARMACINHA
    Integrantes do grupo: Andrey de Assis (HT3004627), Gustavo Stedile Araujo (HT3003787), Lucas de Assis (HT3004619), Matheus Felipe Araujo da Silva (HT3004643), Pedro Henrique Araujo Maia de Mello (HT3004601)

    E-mail para contato: andrey.assis@aluno.ifsp.edu.br
-->

<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <link rel="stylesheet" href="home.css">
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.4.1/css/all.css">

        <title>FARMAT - Home</title>
    </head>
    <body>
        <div class="navbar">
            <a href="home.php" class="logo">
                <img class="logo" src="../../img/logo-white.png" alt="Logo FARMAT"><!--FARMAT-->
            </a>
            <ul class="nav">
                <li><a href="#home" class="current">Home</a></li>
                <li><a href="#sobre">Sobre</a></li>
                <li><a href="#minha-farmacinha">Minha Farmacinha</a></li>
                <li><a href="#equipe">Quem somos</a></li>
                <li><a href="#dicas">Dicas</a></li>
                <li><a href="#contato">Contato</a></li>
            </ul>
        </div>

        <!--<div class="banner-darken"></div>-->

        <div id="home" class="banner-area">
            <div class="nav-hitbox"></div>
            <div class="banner-text">

                <h1>Minha Farmacinha</h1>
                <p>Gerencie seus <span>medicamentos</span> de casa!</p>
                <div class="options-container">
                    <ul class="options">
                        <a href="../signin/signin_page.php"><li>Entrar</li></a>
                        <a href="../signup/signup.html"><li>Cadastrar</li></a>
                    </ul>
                </div>
            </div>

            <div class="credits">
                <p>Foto por Katherine Chase</p>
            </div>
        </div>

        <div class="corpo">
            <div id="sobre" class="bloco">
                <div class="icon">
                    <i id="icon1" class="fas fa-plus"></i>
                </div>
                
                <div class="sobre-farmat">
                    <h2>Sobre a FARMAT</h2>

                    <p>Somos a <span class="enfase">melhor</span> farmácia para você que busca gerenciar, de casa, os seus medicamentos! Desfrute de diversos serviços (ainda sendo trabalhados) desenvolvidos com muito empenho para facilitarem a sua vida de usuário.</p>
                </div>
            </div>

            <div class="bloco" id="minha-farmacinha">
                <div class="farmacinha">
                    <div class="icon">
                        <i id="icon2" class="far fa-clipboard"></i>
                    </div>
                    
                    <h2 id="projeto-farmacinha">O projeto “Minha Farmacinha”</h2>

                    <p>Essa aplicação web tem como objetivo gerenciar os medicamentos/remédios que são comprados e armazenados em casa. A aplicação irá cadastrar os medicamentos, analisando seus vencimentos e suas fórmulas para que, em uma nova compra, o usuário possa consultar a lista e verificar se já possui o produto ou não para uma nova aquisição. <a href="../signin/signin_page.php">Experimente já!</a></p>
                </div>
            </div>

            <div class="bloco" id="equipe">
                <div class="a-equipe-farmat">
                    <div class="icon">
                        <i id="icon3" class="fas fa-users"></i>
                    </div>
                    
                    <h2 id="equipe-farmat">A equipe</h2>

                    <p>Somos todos estudantes compromissados do IFSP (Instituto Federal de São Paulo), do Câmpus Hortolândia, atualmente cursando Informática, no 2º Ano do Ensino Médio.</p>

                    <div class="apresentacao-container">
                        <div class="perfil">
                            <img id="andrey" class="foto" src="../../img/andrey.png" alt="Andrey de Assis">
                            <p class="nome">Andrey de Assis</p><p>Desenvolvedor B</p>
                        </div>

                        <div class="perfil">
                            <img id="gustavo" class="foto" src="../../img/gustavo.jpg" alt="Gustavo Stedile Araujo">
                            <p class="nome">Gustavo Stedile</p><p>Desenvolvedor A</p>
                        </div>

                        <div class="perfil">
                            <img id="lucas" class="foto" src="../../img/lucas.jpg" alt="Lucas de Assis">
                            <p class="nome">Lucas de Assis</p><p>Desenvolvedor A</p>
                        </div>
                        
                        <div class="perfil">
                            <img id="matheus" class="foto" src="../../img/matheus.jpg" alt="Matheus Felipe Araujo da Silva">
                            <p class="nome">Matheus Felipe</p><p>Desenvolvedor A</p>
                        </div>

                        <div class="perfil">
                            <img id="pedro" class="foto" src="../../img/pedro.jpg" alt="Pedro Henrique Araujo Maia de Mello">
                            <p class="nome">Pedro Henrique</p><p>Desenvolvedor B</p>
                        </div>
                    </div>

                </div>
            </div>

            <div class="bloco" id="dicas">
                <div class="dicas-farmat">
                    <div class="icon">
                        <i id="icon4" class="far fa-hand-point-up"></i>
                    </div>

                    <h2 id="dicas-titulo">Dicas para compras on-line</h2>

                    <p>Procurando comprar <span class="enfase">on-line</span> seus medicamentos de maneira segura? Pode deixar com a gente. Confira nossos parceiros perfeitos para você:</p>

                    <div class="externos-container">
                        <div class="externo">
                            <div class="externo-foto-container">
                                <img class="externo-foto" id="droga_raia" src="../../img/drogaraia.png" alt="Droga Raia">
                            </div>
                            
                            <div class="externo-info-container">
                                <div class="externo-info">
                                    <h3>Droga Raia</h3>
                                    <p>Testados por pediatras e dermatologistas. Produtos com fórmula hipoalergênica, que protegem a pele e cabelo de ressecamento. Seu bebê merece. Ideal para Recém-Nascidos. Testado por especialistas. Cuidado completo. Suave como água pura.

                                    </p>

                                    <ul class="options">
                                        <a href="https://www.drogaraia.com.br/"><li>Visitar</li></a>
                                    </ul>
                                </div>
                            </div>

                            <div class="icon-externo">
                                <i class="fas fa-quote-right"></i>
                            </div>
                        </div>

                        <div class="externo">
                            <div class="externo-foto-container">
                                <img class="externo-foto" id="drogasil" src="../../img/drogasil.png" alt="Drogasil">
                            </div>
                            
                            <div class="externo-info-container">
                                <div class="externo-info">
                                    <h3>Drogasil</h3>
                                    <p>A Drogasil é uma farmácia que conta com uma ampla variedade de produtos. Medicamentos, remédios genéricos, vitaminas, dermocosméticos e muito mais...

                                    </p>

                                    <ul class="options">
                                        <a href="https://www.drogasil.com.br/"><li>Visitar</li></a>
                                    </ul>
                                </div>
                            </div>

                            <div class="icon-externo">
                                <i class="fas fa-quote-right"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="bloco" id="contato">
                <div class="contato">
                    <div class="icon">
                        <i id="icon5" class="fas fa-headphones-alt"></i>
                    </div>

                    <h2 id="contato-farmat">Contato</h2>

                    <p>A FARMAT conta com atendimento 24h ao cliente. Note que, devido a <span class="enfase">pandemia global</span> atualmente enfrentada, nossos serviços estão disponíveis apenas a distância.</p>

                    <div class="contact-form">
                        <p><span class="enfase">Endereço de e-mail suporte</span>: andrey.assis@aluno.ifsp.edu.br</p>
                    </div>

                    <div class="contact-form">
                        <p><span class="enfase">Endereço físico</span>: Av. Thereza Ana Cecon Breda, 1896 - Vila Sao Pedro, Hortolândia - SP, 13183-091</p>

                        <div class="maps-container">
                            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3676.6905173531572!2d-47.23335228503546!3d-22.850936785040215!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x94c8bc16c66f0bed%3A0x1aee5c111efc6196!2sInstituto%20Federal%20de%20Educa%C3%A7%C3%A3o%2C%20Ci%C3%AAncia%20e%20Tecnologia%20de%20S%C3%A3o%20Paulo%2C%20Campus%20Hortol%C3%A2ndia!5e0!3m2!1spt-BR!2sbr!4v1628901558596!5m2!1spt-BR!2sbr" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="bloco-exc">
            <div class="contador-container">
                <?php include "contador/mensagem_contador.php" ?>
            </div>
        </div>

        <div class="bloco" id="rodape">
            <div class="rodape-container">
                <div class="rodape">
                    <p>Política de privacidade | © 2021. Todos os direitos reservados.</p>
                </div>
            </div>
        </div>

    </body>

    <script src="main.js"></script>
</html>