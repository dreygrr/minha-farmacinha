<?php
    function escrever(int $valor, string $path): void {
        $out = fopen("$path", "w");
        fwrite($out, $valor); fclose($out);
    }
    
    function get_contador(string $path): int {
        $in = fopen($path, "r");
        if (!$in) echo "oi";
        $valor = (int) fread($in, 10);
        escrever(++$valor, $path); fclose($in);
        return $valor;
    }
?>