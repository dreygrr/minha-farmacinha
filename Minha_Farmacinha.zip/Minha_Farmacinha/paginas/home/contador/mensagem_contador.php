<?php
    require_once "contador.php";
    $numero = get_contador("contador/contador.txt");
    echo "<p>Você é o ${numero}° visitante!</p>";
?>