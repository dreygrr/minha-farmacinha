<?php
    session_start();

    $conexao = mysqli_connect('localhost', 'root', '', 'farmat_minhafarmacinha');
?>

<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <link rel="stylesheet" href="./menu_usuario.css">
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.4.1/css/all.css">
        <title>FARMAT - Menu</title>
    </head>
    <body>
        <div class="navbar">
            <a href="../home/home.php" class="logo">
                <img class="logo" src="../../img/logo-white.png" alt="Logo FARMAT"><!--FARMAT-->
            </a>
            <ul class="nav">
                <li><a href="#home" class="current">Home</a></li>
                <li><a href="#sobre">Sobre</a></li>
                <li><a href="#minha-farmacinha">Minha Farmacinha</a></li>
                <li><a href="#equipe">Quem somos</a></li>
                <li><a href="#dicas">Dicas</a></li>
                <li><a href="#contato">Contato</a></li>
            </ul>
        </div>

        <div class="bloco">

            <div class="user-container">
                <div class="perfil-container">
                    <div class="pic-container">
                        <?php
                            $email = $_SESSION['email'];
                            
                            $nomepic = mysqli_query($conexao,"SELECT * FROM usuario WHERE email = '$email'");
                            $pic = mysqli_fetch_assoc($nomepic);

                            echo "<img class='ppic' src='../../img/ppic/".$pic['foto']."' height=100%'>";
                        ?>

                        <!--<i class="fad fa-user"></i>-->
                    </div>

                    <?php
                    echo "<h2>" . $_SESSION['nome'] . "</h2>";
                    ?>

                    <div class="descricao-user-container">
                        <p class="descricao-user">Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
                    </div>
                </div>
            </div>
        
            <div class="options-container">
                <ul class="options">
                    <a href="./../cadastrar_remedio/cadastrar_remedio.html"><li>Cadastrar remédio</li></a>
                </ul>

                <ul class="options">
                    <a href="#"><li>Opção 2 (wip)</li></a>
                </ul>
            </div>
            
            <div class="back-to-home">
                <a href="./../../index.php"><p>Voltar para a home</p></a>
            </div>

        </div>
    </body>
</html>