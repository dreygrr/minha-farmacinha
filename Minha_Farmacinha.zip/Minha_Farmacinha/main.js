const audio = new Audio('sound/bem-te-vi.mp3');
audio.volume = .05;
setTimeout(() => audio.play(), 0);